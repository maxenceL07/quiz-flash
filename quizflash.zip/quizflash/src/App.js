
import { useState } from "react";
import "./App.css";

const questions = [
  {
    question: "Quelle est la capitale de l'Australie ?",
    options: ["Sydney", "Melbourne", "Canberra", "Perth"],
    answer: "Canberra",
  },
  {
    question: "Combien de planètes composent notre système solaire ?",
    options: ["7", "8", "9", "10"],
    answer: "8",
  },
  {
    question: "Qui a peint la Joconde ?",
    options: ["Van Gogh", "Picasso", "Léonard de Vinci", "Monet"],
    answer: "Léonard de Vinci",
  },
  {
    question: "Quel est le plus grand océan du monde ?",
    options: ["Atlantique", "Indien", "Arctique", "Pacifique"],
    answer: "Pacifique",
  },
  {
    question: "En quelle année l'homme a-t-il marché sur la Lune ?",
    options: ["1965", "1969", "1972", "1959"],
    answer: "1969",
  },
];

function App() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (option) => {
    if (option === questions[currentQuestion].answer) {
      setScore(score + 1);
    }
    const next = currentQuestion + 1;
    if (next < questions.length) {
      setCurrentQuestion(next);
    } else {
      setShowResult(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowResult(false);
  };

  return (
    <div className="App">
      <h1>QuizFlash - Culture Générale</h1>
      {showResult ? (
        <div className="result">
          <h2>Ton score : {score} / {questions.length}</h2>
          <button onClick={resetQuiz}>Rejouer</button>
        </div>
      ) : (
        <div className="quiz-box">
          <h2>Question {currentQuestion + 1} / {questions.length}</h2>
          <p>{questions[currentQuestion].question}</p>
          <div className="options">
            {questions[currentQuestion].options.map((option, index) => (
              <button key={index} onClick={() => handleAnswer(option)}>{option}</button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
